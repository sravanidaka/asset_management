import React from 'react';
import { Button, Dropdown } from 'antd';
import { DownloadOutlined, DownOutlined } from '@ant-design/icons';
import { handleExport, formatDataForExport } from '../utils/exportUtils';

const ExportButton = ({ 
  data, 
  columns, 
  filename, 
  title, 
  reportType, 
  filters = {}, 
  sorter = {},
  message 
}) => {
  const handleExportClick = (exportType) => {
    try {
      const formattedData = formatDataForExport(data, columns);
      const result = handleExport(
        exportType,
        formattedData,
        columns,
        filename,
        title,
        reportType,
        filters,
        sorter
      );

      if (result.success) {
        const recordCount = result.recordCount || formattedData.length;
        message.success(`${exportType.toUpperCase()} export completed successfully. ${recordCount} records exported.`);
      } else {
        message.error(`Failed to export ${exportType.toUpperCase()}: ${result.error}`);
      }
    } catch (error) {
      console.error('Export error:', error);
      message.error('Export failed. Please try again.');
    }
  };

  const exportMenuItems = [
    {
      key: 'excel',
      label: 'Export to Excel',
      icon: <DownloadOutlined />,
      onClick: () => handleExportClick('excel')
    },
    {
      key: 'pdf',
      label: 'Export to PDF',
      icon: <DownloadOutlined />,
      onClick: () => handleExportClick('pdf')
    }
  ];

  return (
    <Dropdown
      menu={{ items: exportMenuItems }}
      trigger={['click']}
      placement="bottomRight"
    >
      <Button icon={<DownloadOutlined />}>
        Export <DownOutlined />
      </Button>
    </Dropdown>
  );
};

export default ExportButton;

